from socket import *
from os import system,name
import string
import other.Dictoh as Dictoh


# Todo solo Presentazione niente relazione
# ToDo Client-Server

CheckCol = ["A","B","C","D","E","F","G","H","I","L"] # To check characters
CheckRow = string.digits # All digits/numbers in string format

# Default amount is 1 ac, 2 cr, 3 tb, 4 sb
ac = 0 # Aircraft Carrier amount
cr = 0 # Cruisers amount
tb = 0 # Torpedo Ships amount
sb = 0 # Submarines amount
cships = 0 # Total ships amount
hitpoints = 0 # Hitpoints of all the ships

#A[Riga][Colonna]
# 9 Grid Height not used
# 9 # Grid Width not used

OwnMap = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]

EnemyMap = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]

# -------------------------------------------------- # -------------------------------------------------- #  
def Clear(): # Clears the console for Windows and Linux/Mac
    # Windows
    if name == 'nt':
        _ = system('cls')
 
    # Mac and Linux(os.name is 'posix')
    else:
        _ = system('clear')


def Introduction(): # Starts the game directly or shows rules before
    tt = 0

    while (tt!= 1 and tt!=2):
        try:

            print("Welcome to Battleship in Python! 🛳️  💣  🐍\n")
            tt = int(input("Press 1 to play, 2 to read rules: "))
            
            if tt not in (1, 2):
                
                Clear()
                print("Invalid choice. Please enter 1 or 2.\n")

        except ValueError:
            Clear()
            print("Invalid input. Please enter a number (1 or 2).\n")

    
    if(tt == 1):
        Clear()
        print("Game started!\n")
        pass
    else:

        Clear()
        print("\n\033[31m\033[40m---------------------------------------- RULES --------------------------------------------------\033[0m")
        print("Battleship is a classic strategy game for two players.\n"
            "Here's a quick view of the rules:\n\n"
            "\033[31mObjective:\033[0m\n"
            "Sink all of your opponent's ships before they sink yours.\n\n"
            "\033[31mSetup:\033[0m\n"
            "  Each player gets a game board with a grid of squares(10x10) hidden from each other.\n"
            "  Players secretly place their ships on their grids, following specific rules (Ships can't overlap).\n\n"
            "\033[31mGameplay:\033[0m\n"
            "  Players take turns calling out coordinates (letter-number combinations) on the opponent's grid, trying to hit their ships.\n"
            "  If a player hits a ship, the grid will show a \"X\" mark in the square on their board.\n"
            "  If a player misses, the grid will show a \"#\" mark in the square on their board.\n"
            "  The game continues with players taking turns firing shots until.\n"
            "  One player sinks all their opponent's ships: The player who achieves this first wins the game!\n\n"
            "\033[31mTips:\033[0m\n"
            "  Strategically placing your ships can make it harder for your opponent to guess their locations.\n"
            "  Keep track of your opponent's shots to try and predict where their ships might be hidden.")
        cutscene = input("\nPress ENTER when you are done reading!\n")
        
        Clear()
        print("Game started!\n")


def PrintMap(maph): # Prints the battleship map (Matrix)
    print("\n\033[31m\033[40m----- Battleship Map -----\033[0m\n")
    print("Legend:")
    print("  \033[31mX\033[0m  - Successful Shot")
    print("  \033[33m#\033[0m  - Missed Shot")
    print("  \033[32mA\033[0m  - Ship is fine")
    print("  \033[31mH\033[0m  - Ship has been shot")

    print("\033[36m  --------------------- \033[0m") # 21


    for x in range(0,10):

        pr = ""

        for y in range(0,10):

            if(str(maph[x][y]) == "0"): # Empty

                pr = pr + "\033[44m| \033[0m" 

            elif(str(maph[x][y]) == "1"): # Successful shot
            
                pr = pr + "\033[44m|\033[0m\033[31mX\033[0m"

            elif(str(maph[x][y]) == "2"): # Missed shot

                pr = pr + "\033[44m|\033[0m\033[33m#\033[0m"

            elif(str(maph[x][y]) == "3"): # Ship is fine

                pr = pr + "\033[44m|\033[0m\033[32mA\033[0m" 

            elif(str(maph[x][y]) == "4"): # Enemy Hit Your ship

                pr = pr + "\033[44m|\033[0m\033[31mH\033[0m" 
            
        print("\033[37m\033[40m" + str(x) + ")\033[0m" + pr + "\033[44m|\033[0m")

    print("\033[36m  --------------------- \033[0m")
    print("\033[37m\033[40m   A B C D E F G H I L  \033[0m")


def Avships(): # Prints the available ships
        print("You have available:\n\n"

          f"A : You have  {str(ac)}  Aircraft Carrier (4 Squares) left to place.\n"
          f"B : You have  {str(cr)}  Cruiser (3 Squares) left to place.\n"
          f"C : You have  {str(tb)}  Torpedo ship (2 Squares)left to place.\n"
          f"D : You have  {str(sb)}  Submarine (1 Squares)left to place.\n"

        )


def CheckCc(bd): # Checks the given coordinates 1 = Building
    if(bd == True): # If bd(building) is on 

        while True:
            cc = str(input("Choose the COLUMN and ROW where you want to place your ship (Ex: A5): ")).upper()

            # Check length (2 characters) and individual characters (column and row)
            if len(cc) != 2 or cc[0] not in CheckCol or cc[1] not in CheckRow:
                
                print("Invalid input. Please enter a valid column (A-L) and row (0-9) combination (Ex: A5).\n")
                continue  # Does another loop if the condition is invalid
            else:

                cn = Dictoh.LtS[cc[0]] # Converts the letter in the corresponding number/digit
                cc = str(cn) + str(cc[1]) # Merges the number/digit with the other digit in the same string
                if(OwnMap[int(cc[1])][int(cc[0])] != 0):

                    print("Invalid input. There is already another ship at those coordinates!\n")
                    continue # Does another loop if the condition is invalid
            
            return cc
        
    else: # If bd(building) is off

        while True:
            cc = str(input("Choose the COLUMN and ROW where you want to shoot (Ex: A5): ")).upper()

            # Check length (2 characters) and individual characters (column and row)
            if len(cc) != 2 or cc[0] not in CheckCol or cc[1] not in CheckRow:
                
                print("Invalid input. Please enter a valid column (A-L) and row (0-9) combination (Ex: A5).\n")
                continue  # Does another loop if the condition is invalid

            cn = Dictoh.LtS[cc[0]] # Converts the letter in the corresponding number/digit
            cc = str(cn) + str(cc[1]) # Merges the number/digit with the other digit in the same string
            return cc


def ChooseAmount(): # Sets the amount of total ships
    global ac
    global cr
    global tb
    global sb
    global cships
    global hitpoints

    print("You will choose how many ships you want to play with!")

    while(int(ac) > 2 or int(ac) <  1):
        try:
            ac = int(input("Choose the amount of Aircraft Carriers you will have(max 2)."))
        except:
            print("Invalid input. Needs to be an integer.")

    while(int(cr) > 4 or int(cr) <  1): 
        try:
            cr = int(input("Choose the amount of Cruisers you will have(max 4)."))
        except:
            print("Invalid input. Needs to be an integer.")

    while(int(tb) > 6 or int(tb) <  1): 
        try:
            tb = int(input("Choose the amount of Torpedo Boats you will have(max 6)."))
        except:
            print("Invalid input. Needs to be an integer.")

    while(int(sb) > 8 or int(sb) <  1):
        try:
            sb = int(input("Choose the amount of Submarines you will have(max 8)."))
        except:
            print("Invalid input. Needs to be an integer.")

    cships = ac + cr + tb + sb # Total ships amount
    hitpoints = (ac*4) + (cr*3) + (tb*2) + (sb*1) # Hitpoints of all the ships
    msg = str(ac)+str(cr)+str(tb)+str(sb)
    return msg
    

def CheckDirection(cc,bt): # Checks if it's possible to place the ship in the chosen direction, Requests choosen coordinates and ship type selected
    valid_directions = ("W", "A", "S", "D")
    flag = True
    dr = ""
    area = 0

    match bt:
        case "A": # Aircraft Carrier
            area = 4

        case "B": # Cruiser
            area = 3

        case "C": # Torpedo ships
            area = 2

        case _: # Case Exception
            Clear()
            print("Invalid input. Please enter a valid type.")

    while True: # Direction selection
        dr = str(input("Now select the direction of the ship (W,A,S,D):")).upper()

        if dr in valid_directions:
            # Valid direction entered, proceed
            break
        else:
            Clear()
            print("\nInvalid direction. Please choose from W, A, S, or D.\n")


    match dr: # Works like switch, checks the direction and then places the ship if possible
        case "W": # Up
            if((int(cc[1]) - (area - 1)) >= 0): # Checks if it doesn't go outside the bound of the map
                for x in range(0,area): # Checks all the area that the ship will take
                    if(int(OwnMap[int(cc[1]) - x][int(cc[0])]) == 0): # If a slot is not free puts the flag to False
                        pass # Does nothing
                    else:
                        flag = False
                if(flag == True): # If flag is true then places the ship
                    for x in range(0,area):
                        OwnMap[int(cc[1]) - x][int(cc[0])] = 3
                        Clear()
                    print("\nSuccessfully placed the selected ship!\n")
                    return True
            else:
                    Clear()
                    print("Can't place in the selected coordinates, outside the bound of the map!\n")
                    return False

        case "A": # Left
            if((int(cc[0]) - (area - 1)) >= 0): # Checks if it doesn't go outside the bound of the map
                print("Left")
                for x in range(0,area): # Checks all the area that the ship will take
                    if(int(OwnMap[int(cc[1])][int(cc[0]) - x]) == 0): # If a slot is not free puts the flag to False
                        pass # Does nothing
                    else:
                        flag = False
                if(flag == True): # If flag is true then places the ship
                    for x in range(0,area):
                        OwnMap[int(cc[1])][int(cc[0]) - x] = 3
                        Clear()
                    print("\nSuccessfully placed the selected ship!\n")
                    return True
            else:
                    Clear()
                    print("Can't place in the selected coordinates, outside the bound of the map!\n")
                    return False

        case "S": # Down
            if((int(cc[1]) + (area - 1)) <= 9): # Checks if it doesn't go outside the bound of the map
                for x in range(0,area): # Checks all the area that the ship will take
                    if(int(OwnMap[int(cc[1]) + x][int(cc[0])]) == 0): # If a slot is not free puts the flag to False
                        pass # Does nothing
                    else:
                        flag = False
                if(flag == True): # If flag is true then places the ship
                    for x in range(0,area):
                        OwnMap[int(cc[1]) + x][int(cc[0])] = 3
                        Clear()
                    print("\nSuccessfully placed the selected ship!\n")
                    return True
            else:
                    Clear()
                    print("Can't place in the selected coordinates, outside the bound of the map!\n")
                    return False

        case "D": # Right
            if((int(cc[0]) + (area - 1)) <= 9): # Checks if it doesn't go outside the bound of the map
                for x in range(0,area): # Checks all the area that the ship will take
                    if(int(OwnMap[int(cc[1])][int(cc[0]) + x]) == 0): # If a slot is not free puts the flag to False
                        pass # Does nothing
                    else:
                        flag = False
                if(flag == True): # If flag is true then places the ship
                    for x in range(0,area):
                        OwnMap[int(cc[1])][int(cc[0]) + x] = 3
                        Clear()
                    print("\nSuccessfully placed the selected ship!\n")
                    return True
            else:
                    Clear()
                    print("Can't place in the selected coordinates, outside the bound of the map!\n")
                    return False


def PlaceShips(): # Ships placer
    global ac # Aircraft Carrier
    global cr # Cruiser
    global tb # Torpedo Ship
    global sb # Submarine
    global cships # Total ships

    print("You will now place your ships!\n")
    if(cships > 0):
        while(cships > 0): # Cycles until total ships = 0
            flag = True
            cc = "##"
            Avships()
            bt = str(input("Select the id of which type of ship to place (A,B,C,D): ")).upper()

            match bt:
                case "A":
                    if(ac > 0):
                        Clear()
                        print("You have selected to place an Aircraft Carrier\n")
                        PrintMap(OwnMap)

                        cc = CheckCc(1) # 1 = Building mode
                        flag = CheckDirection(cc,bt)
                        if(flag == True):
                            ac = ac - 1
                            cships = cships - 1
                            PrintMap(OwnMap)
                    else:
                        Clear()
                        print("You don't have any ship of this type left!")

                case "B":
                    if(cr > 0):
                        Clear()
                        print("You have selected to place a Cruiser\n")
                        PrintMap(OwnMap)

                        cc = CheckCc(1) # 1 = Building mode
                        flag = CheckDirection(cc,bt)
                        if(flag == True):
                            cr = cr - 1
                            cships = cships - 1
                            PrintMap(OwnMap)
                    else:
                        Clear()
                        print("You don't have any ship of this type left!")

                case "C":
                    if(tb > 0):
                        Clear()
                        print("You have selected to place a Torpedo ship\n")
                        PrintMap(OwnMap)

                        cc = CheckCc(1) # 1 = Building mode
                        flag = CheckDirection(cc,bt)
                        if(flag == True):
                            tb = tb - 1
                            cships = cships - 1
                            PrintMap(OwnMap)
                    else:
                        Clear()
                        print("You don't have any ship of this type left!")

                case "D":
                    if(sb > 0):
                        Clear()
                        print("You have selected to place a Submarine\n")
                        PrintMap(OwnMap)
                        cc = CheckCc(1) # 1 = Building mode
                        OwnMap[int(cc[1])][int(cc[0])] = 3
                        sb = sb - 1
                        cships = cships - 1
                        PrintMap(OwnMap)

                    else:
                        Clear()
                        print("You don't have any ship of this type left!")

                case _: # Case exception
                    Clear()
                    print("Invalid input. Please enter a valid type.")
        Clear()
        print("All ships have been placed!\n")
    else:
        print("You don't have any ships left to place!\n")


def FireAShot(): # Shooting mode
    sc = CheckCc(0) # 0 for shooting
    msg = str(sc) + "2"
    Send(msg)
    rp = Listen()

    match int(rp):
        case 1:
            print("You hit an enemy ship!")
            EnemyMap[int(sc[1])][int(sc[0])] = 1
            return 0
        
        case 2:
            print("You missed!")
            EnemyMap[int(sc[1])][int(sc[0])] = 2
            return 0
        
        case 3:
            print("You destroyed the last enemy ship!\n")
            return 3
        case 10:
            print("You must be dumb! You already hit that position!")
            return 0

def Send(msg): # Sends messagges to the other party
    clientSocket.send(str(msg).encode('utf-8'))

def Listen(): # Listens to the other party messages

    print("Waiting for response.")
    ans = clientSocket.recv(1024)
    ans = ans.decode('utf-8')
    return ans
# -------------------------------------------------- # -------------------------------------------------- #  
wc = 0 # Win condition
sts = 0 # Variable to save coord
status = 0 # Turns
choice = 0 # Actions
gameon = True # Keep game going

serverName = "localhost"
serverPort = 34098
clientSocket = socket(AF_INET,SOCK_STREAM) # Socket TCP


try:
    clientSocket.connect((serverName,serverPort))
    print("Successful connection to the server!\n")
    Introduction()
    msg = ChooseAmount()
    PlaceShips()
    Send(msg)
except:
    gameon = False
    print("Connection failed try again!\n")
    

while(gameon == True): # Cycle
    
    if(int(status) == 0): # Waiting
        status = str(Listen())
        if(len(status) == 3):
            sts = status[0] + status[1]
            status = 2

    elif(int(status) == 1): # Turn
        while(int(choice) < 1 or int(choice) > 4):
            try:
                choice = int(input("\nSelect your next action!\n"
                            "1 - Shoot!\n"
                            "2 - View your map!\n"
                            "3 - View your knowledge of the enemy map!\n"
                            ))
            except:
                print("Invalid input. Try again!\n")

            match int(choice):
                case 1:
                    Clear()
                    PrintMap(EnemyMap)
                    wc = FireAShot()
                    PrintMap(EnemyMap)
                    if(wc == 3):
                        print("Congratulations you won the game!")
                        clientSocket.close()
                        break

                    choice = 0
                    status = 0
                    break
                    
                case 2: # Shows own map
                    Clear()
                    PrintMap(OwnMap)
                    choice = 0

                case 3: # Shows enemy map
                    Clear()
                    PrintMap(EnemyMap)
                    choice = 0
    elif(int(status) == 2): # Enemy's turn
        Clear()
        print(f"Enemy is shooting!")
        if(OwnMap[int(sts[1])][int(sts[0])] == 4 or OwnMap[int(sts[1])][int(sts[0])] == 2):
            print("Enemy has got brain damage!")
            Send(10)
            status = 1
        elif(OwnMap[int(sts[1])][int(sts[0])] != 3):
            print("Missed")
            OwnMap[int(sts[1])][int(sts[0])] = 2
            Send(2)
            status = 1
        else:
            print("One of your ships got hit!")
            OwnMap[int(sts[1])][int(sts[0])] = 4
            PrintMap(OwnMap)
            if((hitpoints-1) <= 0):
                print("You lost!")
                Send(3)
                gameon = False
                clientSocket.close()
                break
            else:
                hitpoints = hitpoints - 1
                Send(1)
                status = 1