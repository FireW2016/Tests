LtS = { # Letter To Row/Translates the letter for the row in a number

 "A": 0,
 "B": 1,
 "C": 2,
 "D": 3,
 "E": 4,
 "F": 5,
 "G": 6,
 "H": 7,
 "I": 8,
 "L": 9,

}
